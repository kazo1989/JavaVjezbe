import java.util.ArrayList;

public class Game {

    private Player player;
    private ArrayList<Enemy> enemies;
    private ArrayList<String> eventLog;

    public Game(Player player) {
        if (player == null) {
            throw new IllegalArgumentException("Igrac ne smije biti null");
        }
        this.player = player;
        this.enemies = new ArrayList<Enemy>();
        this.eventLog = new ArrayList<String>();
    }

    public boolean checkCollision(Player p, Enemy e) {
        if (p == null || e == null) {
            throw new IllegalArgumentException("Igrac ili neprijatelj je null");
        }
        return p.intersects(e);
    }

    public void decreaseHealth(Player p, Enemy e) {
        if (p == null || e == null) {
            throw new IllegalArgumentException("Igrac ili neprijatelj je null");
        }
        int staraVrijednost = p.getHealth();
        int efektivnaSteta = e.getEffectiveDamage();
        int novaVrijednost = staraVrijednost - efektivnaSteta;
        if (novaVrijednost < 0) {
            novaVrijednost = 0;
        }
        p.setHealth(novaVrijednost);
        String zapis = "POGODAK: " + p.getDisplayName() + " od " + e.getDisplayName()
                + " za " + efektivnaSteta
                + " -> HP " + staraVrijednost + " -> " + novaVrijednost;
        eventLog.add(zapis);
    }

    public void addEnemy(Enemy e) {
        if (e == null) {
            throw new IllegalArgumentException("Neprijatelj ne smije biti null");
        }
        enemies.add(e);
        eventLog.add("Dodat neprijatelj: " + e.toString());
    }

    public ArrayList<Enemy> findByType(String query) {
        ArrayList<Enemy> rezultat = new ArrayList<Enemy>();
        if (query == null) {
            return rezultat;
        }
        String q = query.toLowerCase();
        for (Enemy e : enemies) {
            if (e.getType().toLowerCase().contains(q)) {
                rezultat.add(e);
            }
        }
        return rezultat;
    }

    public ArrayList<Enemy> collidingWithPlayer() {
        ArrayList<Enemy> rezultat = new ArrayList<Enemy>();
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                rezultat.add(e);
            }
        }
        return rezultat;
    }

    public void resolveCollisions() {
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                decreaseHealth(player, e);
            }
        }
    }

    public static Enemy parseEnemy(String line) {
        if (line == null) {
            throw new IllegalArgumentException("Linija je null");
        }
        String[] dijelovi = line.split(";");
        if (dijelovi.length != 5) {
            throw new IllegalArgumentException("Ocekivano je 5 dijelova: ime;pozicija;velicina;steta;tip");
        }

        String type = dijelovi[0].trim();
        String pozicija = dijelovi[1].trim();
        String velicina = dijelovi[2].trim();
        String damageStr = dijelovi[3].trim();
        String tipNeprijatelja = dijelovi[4].trim().toLowerCase();

        String[] xy = pozicija.split(",");
        if (xy.length != 2) {
            throw new IllegalArgumentException("Neispravna pozicija: " + pozicija);
        }

        int x;
        int y;
        int damage;

        try {
            x = Integer.parseInt(xy[0].trim());
            y = Integer.parseInt(xy[1].trim());
            damage = Integer.parseInt(damageStr);
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Neispravan broj u liniji: " + line);
        }

        Collidable collider;

        if (velicina.contains("x")) {
            String[] wh = velicina.split("x");
            if (wh.length != 2) {
                throw new IllegalArgumentException("Neispravna velicina: " + velicina);
            }
            int sirina;
            int visina;
            try {
                sirina = Integer.parseInt(wh[0].trim());
                visina = Integer.parseInt(wh[1].trim());
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("Neispravne dimenzije: " + velicina);
            }
            collider = new RectangleCollider(x, y, sirina, visina);
        } else {
            int r;
            try {
                r = Integer.parseInt(velicina.trim());
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException("Neispravna velicina: " + velicina);
            }
            collider = new CircleCollider(x, y, r);
        }

        int health = 100;
        Enemy enemy;
        if (tipNeprijatelja.equals("boss")) {
            enemy = new BossEnemy(type, x, y, collider, damage, health);
        } else {
            enemy = new MeleeEnemy(type, x, y, collider, damage, health);
        }
        return enemy;
    }

    public static void main(String[] args) {
        Player p = new Player(" peTar petrović ", 10, 5, 32, 32, 100);

        Game igra = new Game(p);

        Enemy e1 = new MeleeEnemy("Goblin", 12, 5, new RectangleCollider(12, 5, 16, 16), 20, 60);

        Enemy e2 = Game.parseEnemy("Goblin King;12,5;32x32;25;boss");

        igra.addEnemy(e1);
        igra.addEnemy(e2);

        System.out.println("Neprijatelji u igri:");
        for (Enemy e : igra.enemies) {
            System.out.println(e);
        }

        System.out.println();
        System.out.println("Neprijatelji koji u tipu sadrze 'gob':");
        for (Enemy e : igra.findByType("gob")) {
            System.out.println(e);
        }

        System.out.println();
        System.out.println("Stanje igraca prije kolizija:");
        System.out.println(p);

        ArrayList<Enemy> sudari = igra.collidingWithPlayer();
        if (sudari.isEmpty()) {
            System.out.println("Trenutno nema kolizija igraca sa neprijateljima.");
        } else {
            System.out.println("Postoje kolizije sa sljedecim neprijateljima:");
            for (Enemy e : sudari) {
                System.out.println(e.getDisplayName());
            }
        }

        igra.resolveCollisions();

        System.out.println();
        System.out.println("Stanje igraca poslije kolizija:");
        System.out.println(p);

        System.out.println();
        System.out.println("Dnevnik dogadjaja:");
        for (String s : igra.eventLog) {
            System.out.println(s);
        }
    }
}
