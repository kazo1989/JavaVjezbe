public class Player extends GameObject {

    private String name;
    private int health;

    public Player(String name, int x, int y, int sirina, int visina, int health) {
        super(x, y, new RectangleCollider(x, y, sirina, visina));
        setName(name);
        setHealth(health);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null) {
            throw new IllegalArgumentException("Ime ne smije biti null");
        }
        String trimmed = name.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("Ime ne smije biti prazno");
        }

        String[] dijelovi = trimmed.split("\\s+");
        StringBuilder rezultat = new StringBuilder();

        for (int i = 0; i < dijelovi.length; i++) {
            String dio = dijelovi[i].toLowerCase();
            if (dio.isEmpty()) continue;
            char prvo = Character.toUpperCase(dio.charAt(0));
            String ostatak = "";
            if (dio.length() > 1) {
                ostatak = dio.substring(1);
            }
            if (rezultat.length() > 0) {
                rezultat.append(" ");
            }
            rezultat.append(prvo).append(ostatak);
        }

        String finalName = rezultat.toString();
        if (finalName.isEmpty()) {
            throw new IllegalArgumentException("Ime ne smije biti prazno");
        }
        this.name = finalName;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        if (health < 0 || health > 100) {
            throw new IllegalArgumentException("Health mora biti izmedju 0 i 100");
        }
        this.health = health;
    }

    @Override
    public String getDisplayName() {
        return name;
    }

    @Override
    public String toString() {
        Collidable c = getCollider();
        String dimenzije = "";
        if (c instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) c;
            dimenzije = r.getSirina() + "x" + r.getVisina();
        }
        return "Player[" + name + "] @ (" + getX() + "," + getY() + ") " + dimenzije + " HP-" + health + ".";
    }
}
