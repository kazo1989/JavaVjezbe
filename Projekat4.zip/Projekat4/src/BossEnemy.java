public class BossEnemy extends Enemy {

    public BossEnemy(String type, int x, int y, Collidable collider, int damage, int health) {
        super(type, x, y, collider, damage, health);
    }

    @Override
    public int getEffectiveDamage() {
        return getDamage() * 2;
    }

    @Override
    public String toString() {
        Collidable c = getCollider();
        String dimenzije = "";
        if (c instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) c;
            dimenzije = r.getSirina() + "x" + r.getVisina();
        } else if (c instanceof CircleCollider) {
            CircleCollider circle = (CircleCollider) c;
            dimenzije = "r=" + circle.getPoluprecnik();
        }
        return "BossEnemy[" + getDisplayName() + "] @ (" + getX() + "," + getY() + ") "
                + dimenzije + " DMG=" + getDamage() + "x2 HP-" + getHealth() + ".";
    }
}
