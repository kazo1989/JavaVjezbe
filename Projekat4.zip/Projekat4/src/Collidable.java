public interface Collidable {
	
    boolean intersects(Collidable other);
    
}
