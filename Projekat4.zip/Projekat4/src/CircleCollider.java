public class CircleCollider implements Collidable {

    private int x;
    private int y;
    private int poluprecnik;

    public CircleCollider(int x, int y, int poluprecnik) {
        if (poluprecnik <= 0) {
            throw new IllegalArgumentException("Poluprecnik mora biti veci od nule");
        }
        this.x = x;
        this.y = y;
        this.poluprecnik = poluprecnik;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getPoluprecnik() {
        return poluprecnik;
    }

    @Override
    public boolean intersects(Collidable other) {
        if (other instanceof CircleCollider) {
            CircleCollider c = (CircleCollider) other;
            int dx = this.x - c.x;
            int dy = this.y - c.y;
            int rSum = this.poluprecnik + c.poluprecnik;
            return dx * dx + dy * dy <= rSum * rSum;
        } else if (other instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) other;
            int najbliziX = clamp(this.x, r.getX(), r.getX() + r.getSirina());
            int najbliziY = clamp(this.y, r.getY(), r.getY() + r.getVisina());
            int dx = this.x - najbliziX;
            int dy = this.y - najbliziY;
            return dx * dx + dy * dy <= poluprecnik * poluprecnik;
        }

        return false;
    }

    private int clamp(int vrijednost, int min, int max) {
        if (vrijednost < min) return min;
        if (vrijednost > max) return max;
        return vrijednost;
    }
}
