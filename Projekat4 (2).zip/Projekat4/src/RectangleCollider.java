public class RectangleCollider implements Collidable {

    private int x;
    private int y;
    private int sirina;
    private int visina;

    public RectangleCollider(int x, int y, int sirina, int visina) {
        if (sirina <= 0 || visina <= 0) {
            throw new IllegalArgumentException("Dimenzije pravougaonika moraju biti vece od nule");
        }
        this.x = x;
        this.y = y;
        this.sirina = sirina;
        this.visina = visina;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getSirina() {
        return sirina;
    }

    public int getVisina() {
        return visina;
    }

    @Override
    public boolean intersects(Collidable other) {
        if (other instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) other;

            boolean odvojeniPoX = this.x + this.sirina <= r.x || r.x + r.sirina <= this.x;
            boolean odvojeniPoY = this.y + this.visina <= r.y || r.y + r.visina <= this.y;

            return !odvojeniPoX && !odvojeniPoY;
        } else if (other instanceof CircleCollider) {
            return other.intersects(this);
        }

        return false;
    }
}
