package casCetvrtak;
import java.util.Scanner;

public class prvaaKlasa {

	public static void main(String[] args) {
	
		
		Scanner sc = new Scanner(System.in);
		
		double a = sc.nextDouble();
		double b = sc.nextDouble();
		
		double P = a*b;
		double O = 2*a+2*b;
		
		System.out.printf("Povrsina je %.2f, a obim %2.f%n",P,O);
		sc.close();
	}

}
