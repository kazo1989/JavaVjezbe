package casCetvrtak;

import java.util.Scanner;

public class sestiZadatak {

	public static void main(String[] args) {


		Scanner sc = new Scanner(System.in);
		
		double xD = sc.nextDouble(), yD = sc.nextDouble();
		
		
		sc.close();

	}

}
