public interface Attacker {
	
	 int getEffectiveDamage();
	
}