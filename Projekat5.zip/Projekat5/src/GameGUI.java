import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class GameGUI extends JFrame {

    private JTextField imeField, zdravljeField, xField, yField;
    private JRadioButton rectBtn, circleBtn;
    private JButton startBtn;
    private JTextArea outputArea;

    public GameGUI() {
        super("Pokretanje igre");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600);
        setLayout(new BorderLayout());

        // -------------------- PANEL ZA UNOS --------------------
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(6, 2));

        imeField = new JTextField();
        zdravljeField = new JTextField();
        xField = new JTextField();
        yField = new JTextField();

        rectBtn = new JRadioButton("Pravougaoni kolajder");
        circleBtn = new JRadioButton("Kružni kolajder");

        ButtonGroup group = new ButtonGroup();
        group.add(rectBtn);
        group.add(circleBtn);
        rectBtn.setSelected(true);

        inputPanel.add(new JLabel("Ime:"));
        inputPanel.add(imeField);
        inputPanel.add(new JLabel("Početno zdravlje:"));
        inputPanel.add(zdravljeField);
        inputPanel.add(new JLabel("Pozicija X:"));
        inputPanel.add(xField);
        inputPanel.add(new JLabel("Pozicija Y:"));
        inputPanel.add(yField);
        inputPanel.add(rectBtn);
        inputPanel.add(circleBtn);

        startBtn = new JButton("Pokreni igru");
        inputPanel.add(startBtn);

        add(inputPanel, BorderLayout.NORTH);

        // -------------------- OUTPUT --------------------
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        add(new JScrollPane(outputArea), BorderLayout.CENTER);

        // -------------------- LOGIKA DUGMETA --------------------
        startBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pokreniIgru();
            }
        });

        setVisible(true);
    }

    // -------------------- METODA KOJA POKREĆE IGRU --------------------
    private void pokreniIgru() {
        try {
            String ime = imeField.getText();
            int zdravlje = Integer.parseInt(zdravljeField.getText());
            double x = Double.parseDouble(xField.getText());
            double y = Double.parseDouble(yField.getText());

            // kreiranje kolajdera
            Collidable collider;
            if (rectBtn.isSelected()) {
                collider = new RectangleCollider(x, y, 32, 32);
            } else {
                collider = new CircleCollider(16, (float) x, (float) y);
            }

            Player player = new Player(x, y, ime, zdravlje, collider);

            Game game = new Game(player);

            // učitavanje neprijatelja
            ArrayList<Enemy> neprijatelji = Game.loadEnemiesFromCSV("enemies.csv");
            for (Enemy en : neprijatelji) game.addEnemy(en);

            // kolizije
            game.resolveCollisions();

            // ispis rezultata
            outputArea.setText("");
            outputArea.append("--- STATUS IGRAČA ---\n");
            outputArea.append(player.toString() + "\n\n");

            outputArea.append("--- SVI NEPRIJATELJI ---\n");
            for (Enemy en : neprijatelji) outputArea.append(en.toString() + "\n");
            outputArea.append("\n");

            outputArea.append("--- NEPRIJATELJI U KOLIZIJI ---\n");
            for (Enemy en : game.collidingWithPlayer()) outputArea.append(en.toString() + "\n");
            outputArea.append("\n");

            outputArea.append("--- DNEVNIK DOGAĐAJA ---\n");
            for (String s : game.getPodaci()) outputArea.append(s + "\n");

            // poruke
            if (player.getHealth() <= 0) {
                JOptionPane.showMessageDialog(this, "Igrač je poražen!", "Kraj igre", JOptionPane.WARNING_MESSAGE);
            } else if (game.collidingWithPlayer().size() == 0) {
                JOptionPane.showMessageDialog(this, "Igrač je pobijedio!", "Pobjeda", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Greška u unosu podataka!", "Greška", JOptionPane.ERROR_MESSAGE);
        }
    }

    // -------------------- MAIN METODA --------------------
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GameGUI());
    }
}
