
public class TV extends EProizvodi {
	
	private double velicinaEkrana;
	
	public double getVelicinaEkrana() {
		return velicinaEkrana;
	}
	public void setVelicinaEkrana(double velicinaEkrana) {
		this.velicinaEkrana = velicinaEkrana;
	}
	public TV(String opis, String sifra, double velicinaEkrana) {
		super(opis, sifra);
		this.setVelicinaEkrana(velicinaEkrana);
	}
	
	public TV() {
		this(null, null, 0);
	}
	
	@Override
	public float maloprodajnaCijena() {
		return 0;
	}
	
	

}