import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;

public class CurrencyConverter extends JFrame {

    private JTextField txtEur;
    private JTextField txtUsd;
    private JTextField txtGbp;

    // Fiksni kursevi (primjer – možeš ih promijeniti)
    private static final double EUR_TO_USD = 1.08;
    private static final double EUR_TO_GBP = 0.86;

    private boolean updating = false; // da spriječimo beskonačno okidanje listenera

    public CurrencyConverter() {
        super("Konverzija valuta");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        txtEur = new JTextField(10);
        txtUsd = new JTextField(10);
        txtGbp = new JTextField(10);

        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
        panel.add(new JLabel("EUR:"));
        panel.add(txtEur);
        panel.add(new JLabel("USD:"));
        panel.add(txtUsd);
        panel.add(new JLabel("GBP:"));
        panel.add(txtGbp);

        add(panel, BorderLayout.CENTER);

        addListeners();

        pack();
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    private void addListeners() {
        addDocumentListener(txtEur, "EUR");
        addDocumentListener(txtUsd, "USD");
        addDocumentListener(txtGbp, "GBP");
    }

    private void addDocumentListener(JTextField field, String type) {
        field.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                convert(type);
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                convert(type);
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                // ne koristi se za plain tekst
            }
        });
    }

    private void convert(String from) {
        if (updating) return;

        try {
            updating = true;

            if (from.equals("EUR")) {
                double eur = parse(txtEur);
                double usd = eur * EUR_TO_USD;
                double gbp = eur * EUR_TO_GBP;

                txtUsd.setText(format(usd));
                txtGbp.setText(format(gbp));

            } else if (from.equals("USD")) {
                double usd = parse(txtUsd);
                double eur = usd / EUR_TO_USD;
                double gbp = eur * EUR_TO_GBP;

                txtEur.setText(format(eur));
                txtGbp.setText(format(gbp));

            } else if (from.equals("GBP")) {
                double gbp = parse(txtGbp);
                double eur = gbp / EUR_TO_GBP;
                double usd = eur * EUR_TO_USD;

                txtEur.setText(format(eur));
                txtUsd.setText(format(usd));
            }

        } catch (NumberFormatException ex) {
            // ako je unos prazan ili nevažeći, samo ne radimo ništa
        } finally {
            updating = false;
        }
    }

    private double parse(JTextField field) {
        String text = field.getText().trim();
        if (text.isEmpty()) throw new NumberFormatException();
        return Double.parseDouble(text);
    }

    private String format(double value) {
        return String.format("%.2f", value);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CurrencyConverter());
    }
}
