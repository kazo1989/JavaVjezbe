public class Vozilo {
	
	protected String marka;
	protected String model;
	protected int kubikaza;
	protected int godiste;
	protected static float osnovicaZaRegistraciju;

	public String getMarka() {
		return marka;
	}

	public void setMarka(String marka) {
		this.marka = marka;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getKubikaza() {
		return kubikaza;
	}

	public void setKubikaza(int kubikaza) {
		this.kubikaza = kubikaza;
	}

	public int getGodiste() {
		return godiste;
	}

	public void setGodiste(int godiste) {
		this.godiste = godiste;
	}

	public static float getOsnovicaZaRegistraciju() {
		return osnovicaZaRegistraciju;
	}

	public static void setOsnovicaZaRegistraciju(float osnovicaZaRegistraciju) {
		Vozilo.osnovicaZaRegistraciju = osnovicaZaRegistraciju;
	}
	
	public Vozilo(String marka, String model, int kubikaza, int godiste) {
		super();
		this.setMarka(marka);
		this.setModel(model);
		this.setKubikaza(kubikaza);
		this.setGodiste(godiste);
	}
	
	public Vozilo() {
		this(null, null, 0, 0);
	}

	@Override
	public String toString() {
		return "{\n'klasa': 'Vozilo',\n'marka': '" + getMarka() + "',\n'model': '" + getModel() + ",'\n'kubikaza': " + getKubikaza()
				+ ",\n'godiste': " + getGodiste() + "\n}";
	}
	
	public float dajCijenuRegistracije() {
		return 0;
	}	
	

}
