public class Automobil extends Vozilo {
	
	private int brojVrata;
	private int brojOsoba;
	
	
	public int getBrojVrata() {
		return brojVrata;
	}
	public void setBrojVrata(int brojVrata) {
		this.brojVrata = brojVrata;
	}
	public int getBrojOsoba() {
		return brojOsoba;
	}
	public void setBrojOsoba(int brojOsoba) {
		this.brojOsoba = brojOsoba;
	}
	public Automobil(String marka, String model, int kubikaza, int godiste, int brojVrata, int brojOsoba) {
		super(marka, model, kubikaza, godiste);
		this.setBrojVrata(brojVrata);
		this.setBrojOsoba(brojOsoba);
	}
	
	public Automobil() {
		this(null, null, 0, 0, 0, 0);
	}

	
	@Override
	public String toString() {
		return "{\n'klasa': 'Automobil',\n'marka': '" + getMarka() + "',\n'model': '" + getModel() + ",'\n'kubikaza': " + getKubikaza()
				+ ",\n'godiste': " + getGodiste() + ",\n'brojVrata': " + getBrojVrata() + ",\n'brojOsoba': " + getBrojOsoba() + "\n}";
	}
	@Override
	public float dajCijenuRegistracije() {
		return (this.getKubikaza()/ (float) 10.0 + (2025 - this.getGodiste())*10) * Vozilo.getOsnovicaZaRegistraciju();
	}
	
	
	

}
