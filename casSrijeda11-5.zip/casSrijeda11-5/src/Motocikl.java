
public class Motocikl extends Vozilo {
	
	private int kilometraza;

	public int getKilometraza() {
		return kilometraza;
	}

	public void setKilometraza(int kilometraza) {
		this.kilometraza = kilometraza;
	}

	public Motocikl(String marka, String model, int kubikaza, int godiste, int kilometraza) {
		super(marka, model, kubikaza, godiste);
		this.setKilometraza(kilometraza);
	}
	
	public Motocikl() {
		this(null, null, 0, 0, 0);
	}
	
	@Override
	public String toString() {
		return "{\n'klasa': 'Motocikl',\n'marka': '" + getMarka() + "',\n'model': '" + getModel() + ",'\n'kubikaza': " + getKubikaza()
				+ ",\n'godiste': " + getGodiste() + ",\n'kilometraza': " + getKilometraza() + "\n}";
	}
	
	@Override
	public float dajCijenuRegistracije() {
		return (float) (this.getKubikaza() / 5.0 - this.getKilometraza() / 1000.0) * Vozilo.getOsnovicaZaRegistraciju();
	}

}
