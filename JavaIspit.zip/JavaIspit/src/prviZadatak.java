import java.util.Scanner;

public class prviZadatak {

	public static void main(String[] args) {
   		
	   	Scanner sc = new Scanner(System.in);

		System.out.println("Unesi cijeli broj: ");	
	   		
		int cijeliBroj = sc.nextInt();
		
		
		for (int i = 0; i < cijeliBroj; i--) {
			

        }
		
		   		sc.close();
   	}
}
