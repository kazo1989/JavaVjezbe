public class Vjetrometar {
		
		private String nazivMjerneStanice;
		private String datumVrijemeOcitavanja;
		private double maksimalnaBrzinaVjetra;
		private double srednjaBrzinaVjetra;
		private double pravacVjetra;
		
		
	    public Vjetrometar(String nazivMjerneStanice, String datumVrijemeOcitavanja, double maksimalnaBrzinaVjetra, double srednjaBrzinaVjetra, double pravacVjetra) {
	        this.nazivMjerneStanice = nazivMjerneStanice;
	        this.datumVrijemeOcitavanja = datumVrijemeOcitavanja;
	        this.maksimalnaBrzinaVjetra = maksimalnaBrzinaVjetra;
	        this.srednjaBrzinaVjetra = srednjaBrzinaVjetra;
	        this.pravacVjetra = pravacVjetra;
	    }
	    
	    
	    public String getNazivMjerneStanice() {
			return nazivMjerneStanice;
		}
		public void setNazivMjerneStanice(String nazivMjerneStanice) {
			this.nazivMjerneStanice = nazivMjerneStanice;
		}


		public String getDatumVrijemeOcitavanja() {
			return datumVrijemeOcitavanja;
		}
		public void setDatumVrijemeOcitavanja(String datumVrijemeOcitavanja) {
			this.datumVrijemeOcitavanja = datumVrijemeOcitavanja;
		}


		public double getMaksimalnaBrzinaVjetra() {
			return maksimalnaBrzinaVjetra;
		}
		public void setMaksimalnaBrzinaVjetra(double maksimalnaBrzinaVjetra) {
			this.maksimalnaBrzinaVjetra = maksimalnaBrzinaVjetra;
		}


		public double getSrednjaBrzinaVjetra() {
			return srednjaBrzinaVjetra;
		}
		public void setSrednjaBrzinaVjetra(double srednjaBrzinaVjetra) {
			this.srednjaBrzinaVjetra = srednjaBrzinaVjetra;
		}


		public double getPravacVjetra() {
			return pravacVjetra;
		}
		public void setPravacVjetra(double pravacVjetra) {
			this.pravacVjetra = pravacVjetra;
		}

		
	}
