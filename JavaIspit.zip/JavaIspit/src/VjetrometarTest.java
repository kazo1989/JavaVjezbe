import java.util.ArrayList;


public class VjetrometarTest {
	        public static void main(String[] args) {
	            ArrayList<Vjetrometar> vjetrometri = new ArrayList<>();
	            vjetrometri.add(new Vjetrometar("Podgorica", "2025-10-20 14:45:00", 20.2, 7.5, 17.0));
	            vjetrometri.add(new Vjetrometar("Podgorica", "2025-11-01 09:14:00", 10.2, 3.4, 6.0));

	            for (Vjetrometar v : vjetrometri) {
	               
	            }
	        }
	    }