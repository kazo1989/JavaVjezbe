package vjezbeCetvrtak;

public class Auto {
    // Atributi klase
    public String markaAuta;
    public int godisteAuta;
    public double snagaMotora;
    public boolean prodato;
    public double kubikazaMotora;
    public boolean registrovano;
    private static int brojProdatih = 0;

    // Konstruktor
    public Auto(String markaAuta, int godisteAuta, int snagaMotora, boolean prodato, double kubikazaMotora, boolean registrovano) {
        this.markaAuta = markaAuta;
        this.godisteAuta = godisteAuta;
        this.snagaMotora = snagaMotora;
        this.prodato = prodato;
        this.kubikazaMotora = kubikazaMotora;
        
        if (godisteAuta < 1985) {
            this.registrovano = false;
        } else {
            this.registrovano = registrovano;
        }
    }
    
    
    // Geteri i seteri
	public String getMarkaAuta() {
		return markaAuta;
	}

	public void setMarkaAuta(String markaAuta) {
		this.markaAuta = markaAuta;
	}

	public int getGodisteAuta() {
		return godisteAuta;
	}

	public void setGodisteAuta(int godisteAuta) {
		this.godisteAuta = godisteAuta;
	}

	public double getSnagaMotora() {
		return snagaMotora;
	}

	public void setSnagaMotora(double snagaMotora) {
		this.snagaMotora = snagaMotora;
	}

	public boolean isProdato() {
		return prodato;
	}

	public void setProdato(boolean prodato) {
		if (this.prodato != prodato && prodato) brojProdatih++;
		this.prodato = prodato;
	}

	public double getKubikazaMotora() {
		return kubikazaMotora;
	}

	public void setKubikazaMotora(double kubikazaMotora) {
		this.kubikazaMotora = kubikazaMotora;
	}

	public boolean isRegistrovano() {
		return registrovano;
	}

	public void setRegistrovano(boolean registrovano) {
		this.registrovano = registrovano;
	}

	public static int getBrojProdatih() {
		return brojProdatih;
	}   
	
}
