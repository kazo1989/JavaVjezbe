package vjezbeSrijeda;

import java.util.Scanner;

public class drugiZadatak {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Unesite riječ: ");
        String x = sc.nextLine();
        
        String y = new StringBuilder(x).reverse().toString();

        if  (x.equalsIgnoreCase(y)) {
        	System.out.println("Jeste palindrom");
        }
        else {
        	System.out.println("Nije palindrom");
        }
    }
}