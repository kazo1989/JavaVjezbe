pojednostavi mi ovaj kod u javi tako da ga mogu razumjeti, bez kompleksnih izraza i operacija ukoliko su nepotrebne i bez ikakvih dodatnih komentara. Takodje sve sto izlazi u konzoli kao poruka ili outprint prevedi sa engleskog na srpski.

import java.util.ArrayList;

public class Game {

    private Player player;
    private ArrayList<Enemy> enemies;
    private ArrayList<String> eventLog;

    public Game(Player player) {
        this.player = player;
        this.enemies = new ArrayList<>();
        this.eventLog = new ArrayList<>();
    }

    public boolean checkCollision(Player p, Enemy e) {
        return p.getX() < e.getX() + e.getWidth() &&
               p.getX() + p.getWidth() > e.getX() &&
               p.getY() < e.getY() + e.getHeight() &&
               p.getY() + p.getHeight() > e.getY();
    }

    public void decreaseHealth(Player p, Enemy e) {
        int oldHp = p.getHealth();
        int newHp = Math.max(0, oldHp - e.getDamage());
        p.setHealth(newHp);
        String msg = String.format("HIT: Player by %s for %d -> HP %d -> %d",
                e.getType(), e.getDamage(), oldHp, newHp);
        eventLog.add(msg);
    }

    public void addEnemy(Enemy e) {
        enemies.add(e);
        eventLog.add("Enemy added: " + e);
    }

    public ArrayList<Enemy> findByType(String query) {
        ArrayList<Enemy> result = new ArrayList<>();
        for (Enemy e : enemies) {
            if (e.getType().toLowerCase().contains(query.toLowerCase())) {
                result.add(e);
            }
        }
        return result;
    }

    public ArrayList<Enemy> collidingWithPlayer() {
        ArrayList<Enemy> result = new ArrayList<>();
        for (Enemy e : enemies) {
            if (checkCollision(player, e)) {
                result.add(e);
            }
        }
        return result;
    }

    public void resolveCollisions() {
        ArrayList<Enemy> colliding = collidingWithPlayer();
        for (Enemy e : colliding) {
            decreaseHealth(player, e);
        }
    }

    public static void main(String[] args) {

        Player p = new Player("mario bros", 10, 5, 32, 32, 85);
        Game game = new Game(p);

        Enemy e1 = new Enemy("orc", 15, 10, 16, 16, 20);
        game.addEnemy(e1);

        String input = "Goblin;12,5;16x16;20";
        String[] parts = input.split(";");
        String type = parts[0];
        String[] pos = parts[1].split(",");
        String[] size = parts[2].split("x");
        int x = Integer.parseInt(pos[0]);
        int y = Integer.parseInt(pos[1]);
        int width = Integer.parseInt(size[0]);
        int height = Integer.parseInt(size[1]);
        int dmg = Integer.parseInt(parts[3]);
        Enemy e2 = new Enemy(type, x, y, width, height, dmg);
        game.addEnemy(e2);

        System.out.println("=== All Enemies ===");
        for (Enemy e : game.enemies) {
            System.out.println(e);
        }

        System.out.println("\n=== Find by type 'gob' ===");
        for (Enemy e : game.findByType("gob")) {
            System.out.println(e);
        }

        System.out.println("\nPlayer before collisions: " + p);

        game.resolveCollisions();

        System.out.println("Player after collisions: " + p);

        System.out.println("\n=== Event Log ===");
        for (String log : game.eventLog) {
            System.out.println(log);
        }
    }
}