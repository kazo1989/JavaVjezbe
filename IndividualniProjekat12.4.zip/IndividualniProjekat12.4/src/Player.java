

	class Player extends GameObject {

	    private String name;
	    private int health;

	    public Player(double x, double y, String name, int health, Collidable collider) {
	        super(x, y, collider);
	        setName(name);
	        setHealth(health);
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        if (name == null || name.trim().isEmpty()) {
	            System.out.println("Ime igraca ne smije biti prazno");
	            this.name = "Nepoznato";
	            return;
	        }
	        this.name = formatName(name);
	    }

	    private String formatName(String ime) {
	        ime = ime.trim().replaceAll("\\s+", " ");

	        String[] words = ime.split(" ");
	        StringBuilder formatted = new StringBuilder();

	        for (int i = 0; i < words.length; i++) {
	            String w = words[i];

	            formatted.append(Character.toUpperCase(w.charAt(0)));

	            if (w.length() > 1) {
	                formatted.append(w.substring(1).toLowerCase());
	            }
	            if (i < words.length - 1) {
	                formatted.append(" ");
	            }
	        }
	        return formatted.toString();
	    }

	    public int getHealth() {
	        return health;
	    }

	    public void setHealth(int health) {
	        if (health < 0) {
	            System.out.println("Health ne moze biti manji od 0");
	            this.health = 0;
	        } else if (health > 100) {
	            System.out.println("Health ne moze biti veci od 100");
	            this.health = 100;
	        } else {
	            this.health = health;
	        }
	    }

	    @Override
	    public String getDisplayName() {
	        return "Player: " + name;
	    }

	    @Override
	    public String toString() {
	        return "Player[" + name + "] @ (" + getX() + "," + getY() + ") HP=" + health;
	    }
	}

