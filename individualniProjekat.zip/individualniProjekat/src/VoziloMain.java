import java.util.ArrayList;

public class VoziloMain {
    public static void main(String[] args) {
        ArrayList<Vozilo> vozila = new ArrayList<>();
        vozila.add(new Automobil("VW Golf", 2009, 1600, "srebrna", 5, "benzin"));
        vozila.add(new Automobil("Opel Diesel", 2015, 2200, "crna", 5, "dizel"));
        vozila.add(new Kamion("Mercedes", 2005, 5000, "bijela", 12.5, true));
        vozila.add(new Kamion("Scania", 2018, 4800, "crvena", 10.0, false));
        vozila.add(new Kombi("Fiat Ducato", 2012, 2500, "plava", 9));
        vozila.add(new Kombi("Ford Transit", 2008, 2000, "siva", 7));

        for (Vozilo v : vozila) {
            v.ispisi();
            System.out.printf("  Ukupna cijena registracije: %.2f EUR%n%n", v.cijenaRegistracije());
        }
    }
}
