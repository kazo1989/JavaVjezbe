public class EProizvodi {

	protected String opis;
	protected String sifra;
	protected static double uvoznaCijena;
	
	
	public String getOpis() {
		return opis;
	}
	public void setOpis(String opis) {
		this.opis = opis;
	}
	public String getSifra() {
		return sifra;
	}
	public void setSifra(String sifra) {
		this.sifra = sifra;
	}
	public static double getUvoznaCijena() {
		return uvoznaCijena * 1.05;
	}
	public static void setUvoznaCijena(double uvoznaCijena) {
		EProizvodi.uvoznaCijena = uvoznaCijena;
	}
	
	public EProizvodi(String opis, String sifra) {
		super();
		this.setOpis(opis);
		this.setSifra(sifra);
	}
	
	public EProizvodi() {
		this(null, null);
	}
	
	public float maloprodajnaCijena() {
		return 0;
	}
	
	
	
}
