import java.util.ArrayList;


public class VoziloTest {

	public static void main(String[] args) {
		
		Vozilo.setOsnovicaZaRegistraciju(100);
		
		ArrayList<Vozilo> niz = new ArrayList<Vozilo>();
		
		niz.add(new Automobil("Audi", "SQ8", 4000, 2023, 5, 5));
		niz.add(new Automobil("MBW", "M5", 3000, 2000, 5, 5));
		niz.add(new Motocikl("KTM", "1002", 800, 2024, 1000));
		niz.add(new Kamion("SCANIA", "???", 5000, 2000, 10));

	
	
	System.out.println("Sadrzaj voznog parka:");
	for(Vozilo v: niz) {
		System.out.println(v.toString());
	}
	
	float ukupnaCijenaRegistracije = 0;
	
	for(Vozilo v: niz) {
		ukupnaCijenaRegistracije += v.dajCijenuRegistracije();
	}

	System.out.println("Ukupna cijena registracije:" + ukupnaCijenaRegistracije);
	
}
	
}
