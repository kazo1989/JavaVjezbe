package test;

public class koordinate {

    private static double uDecimalneStepene(String s, int brCifri) {
        int d = Integer.parseInt(s.substring(0, brCifri));
        double m = Double.parseDouble(s.substring(brCifri));
        return d + m / 60.0;
    }

    public static String dajPodatke(String meteo) {
        String[] f = meteo.split(",");

        String latS = f[2];
        String ns   = f[3];
        String lonS = f[4];
        String ew   = f[5];

        double lat = uDecimalneStepene(latS, 2);
        double lon = uDecimalneStepene(lonS, 3);

        if (ns.equals("S")) lat = -lat;
        if (ew.equals("W")) lon = -lon;

        return String.format("{smjer: %.3f, 'brzinaSr': %.3f, brzinaMax: %.3f)", lat, lon);

    }

    public static void main(String[] args) {
        String s = "$GNGGA,151603.00,4225.05090,N,01846.12270,E,4,12,0.54,22.1,M,36.8,M,1.0,0004*52";
        System.out.println(dajPodatke(s)); // (42.417515, 18.768711)
    }
}
