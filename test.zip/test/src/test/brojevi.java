package test;

	import java.util.Scanner;

	public class brojevi {

		public static void main(String[] args) {


			Scanner sc = new Scanner(System.in);
			
			System.out.print("Unesite tri cijela broja: ");
			
			int prvi = sc.nextInt();
			int drugi = sc.nextInt();
			int treci = sc.nextInt();
			
			int min = Math.min(prvi, Math.min(drugi, treci));
			int max = Math.max(prvi, Math.max(drugi, treci));
			int mid = prvi + drugi + treci - min - max;
			
			
			System.out.println(min + ", " + max + ", " + mid);
			
			sc.close();
		}
	}