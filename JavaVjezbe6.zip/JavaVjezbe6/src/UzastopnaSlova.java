/*
Dat je string u kojem se neka dva uzastopna slova ponavljaju. Pronaći koja su to slova
*/

import java.util.Scanner;

public class Uzastopna_slova {

	 static void main() {
		 
	        Scanner sc = new Scanner(System.in);
	        String input = sc.nextLine();
	        
	        boolean nadjeno = false;
	        
	        for (int i = 0; i < input.length() - 1; i++) {
	            if (input.charAt(i) == input.charAt(i + 1)) {
	                nadjeno = true;
	                System.out.println("ponovljeni znak: " + input.charAt(i));
	            }
	        }
	        if (!nadjeno) {
	            System.out.println("Nema uzastopnih slova.");
	        }
	        sc.close();
	    }
}
