
public class CircleCollider implements Collidable {
	
	private int x;
	private int y;
	private float r;
	
	
	public CircleCollider(int x, int y, float r) {
		super();
		this.setX(x);
		this.setY(y);
        if (r < 0) {
        	throw new IllegalArgumentException("Poluprecnik ne moze biti negativna.");
        } else {
            this.setR(r);
        }
	}

	public CircleCollider() {
		this(0, 0, 0);
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public float getR() {
		return r;
	}

	public void setR(float r) {
		this.r = r;
	}
	
}
