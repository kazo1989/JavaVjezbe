
public abstract class GameObject implements Collidable {
	
	private int x;
	private int y;
	private Collidable referenca;
	
	
	
	public GameObject(int x, int y, Collidable referenca) {
		super();
		this.setX(x);
		this.setY(y);
		this.setReferenca(referenca);
	}
	
	public GameObject() {
		this(0, 0, null);
	}
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		if (x < 0) {
			
		throw new IllegalArgumentException("Dimenzija ne moze biti negativna.");
		
		} else {
			
			this.x = x;
			
		}
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		if (y < 0) {
			
		throw new IllegalArgumentException("Dimenzija ne moze biti negativna.");
		
		} else {
			
			this.y = y;
			
		}
	}
	public Collidable getReferenca() {
		return referenca;
	}
	public void setReferenca(Collidable referenca) {
		this.referenca = referenca;
	}
	
    public boolean intersects(GameObject other) {
        return this.referenca.intersects(other.referenca);
    }

	
	public abstract String getDisplayName();
	@Override
	public String toString() {
		return "{'klasa': 'GameObject', 'x': '" + getX() + "', 'y': '" + getY() + "', 'referenca': '" + getReferenca() +  "'}";
	}
	
	

}
