
public interface Collidable {
	
	public boolean intersects(Collidable other);

}
