
public class RectangleCollider implements Collidable {
	
	private int x;
	private int y;
	private float sirina;
	private float duzina;
	
	
	public RectangleCollider(int x, int y, float sirina, float duzina) {
		super();
		this.setX(x);
		this.setY(y);
        if (sirina < 0) {
        	throw new IllegalArgumentException("Dimenzija ne moze biti negativna.");
        } else {
            this.setSirina(sirina);
        }
        if (duzina < 0) {
        	throw new IllegalArgumentException("Dimenzija ne moze biti negativna.");
        } else {
            this.setDuzina(duzina);
        }
	}
	
	public RectangleCollider() {
		this(0, 0, 0, 0);
	}
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public float getSirina() {
		return sirina;
	}
	public void setSirina(float sirina) {
		this.sirina = sirina;
	}
	public float getDuzina() {
		return duzina;
	}
	public void setDuzina(float duzina) {
		this.duzina = duzina;
	}
	
	@Override
    public boolean intersects(Collidable other) {
        if (other instanceof RectangleCollider) {
            RectangleCollider r = (RectangleCollider) other;

            boolean odvojeniPoX = this.x + this.sirina  <= r.x || r.x + r.sirina  <= this.x;
            boolean odvojeniPoY = this.y + this.duzina <= r.y || r.y + r.duzina <= this.y;

            return !odvojeniPoX && !odvojeniPoY;
        } 
        else if (other instanceof CircleCollider) {
            return other.intersects(this);
        }

        return false;
    }

	

}
